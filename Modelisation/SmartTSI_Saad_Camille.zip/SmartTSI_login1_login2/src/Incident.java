import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("40bb3989-6c22-43b9-bbb8-c7283738e84e")
public class Incident {
    @objid ("d8d8af04-6200-4f14-a31c-b78e01d006c7")
    private String identifiantEnvoi;

    @objid ("22e8a6c4-5a78-4dd8-8421-26bc16bace3f")
    private String identifiantSourceIoT;

    @objid ("d0790944-db91-4455-a566-3ae5facd59aa")
    private String identifiantPartiePrenante;

    @objid ("4e1f71b3-12a4-4b14-809a-07753a8301fe")
    private String nomAttributDonnéeIoT;

    @objid ("a7ceab84-d268-4acf-a67c-1069786dd82f")
    private double valeurMinimaleAcceptable;

    @objid ("f62d5d59-1842-4da1-8591-5bcf7bf95c29")
    private double valeurMaximaleAcceptable;

    @objid ("d26f8c5a-045c-4533-b21b-33e847ced49f")
    private Date instantCollecte;

    @objid ("4a0b6bbf-adaa-4610-be00-d3e2a4ea885e")
    private Date instantRéception;

    @objid ("40513a03-cc34-497e-87da-77d4abb2194f")
    private double valeur;

}
