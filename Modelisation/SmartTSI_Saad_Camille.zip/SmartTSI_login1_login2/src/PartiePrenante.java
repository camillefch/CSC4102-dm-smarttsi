import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("895707f6-f684-4452-86b7-b1745b8b6c14")
public class PartiePrenante {
    @objid ("e4c88036-7170-4a8e-8773-abcb7d6c641f")
    private String identifiant;

    @objid ("8442b63e-c658-4658-84df-9ea480e355f2")
    private String nom;

    @objid ("ec679afa-0825-4cad-b906-b0e1c1024707")
    private Date dateDébut;

    @objid ("840e0738-0df3-4510-bd47-02e5fede77be")
    private Date dateFin;

}
