import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("a963f5fb-9f3f-4839-b6c3-39ef96e430fa")
public class FaçadeSmartTSI {
    @objid ("c45fb09b-0001-4bc2-9152-fb834daaa75a")
    private List<Envoi>  = new ArrayList<Envoi> ();

    @objid ("a82d13d4-553c-4ca7-acdf-d521d063626b")
    private List<PartiePrenante>  = new ArrayList<PartiePrenante> ();

    @objid ("96fec586-af74-4c5a-a145-4f5cf5a1d083")
    private List<SourceIoT>  = new ArrayList<SourceIoT> ();

    @objid ("b157b706-b6ab-4e0c-adaa-b7251dd11e2b")
    private List<PriseEnCharge>  = new ArrayList<PriseEnCharge> ();

}
